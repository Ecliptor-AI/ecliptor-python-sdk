# Ecliptor Python SDK

## Functions

`pip install ecliptor`

1. ecliptor.adapt(embedding)
Pass in an embedding and get back an embedding multiplied with your adapter